-- MySQL dump 10.11
--
-- Host: localhost    Database: monte122_monte122
-- ------------------------------------------------------
-- Server version	5.0.92-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dips`
--

DROP TABLE IF EXISTS `dips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dips` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `tezis` text NOT NULL,
  `sourse_before` varchar(40) NOT NULL,
  `sourse_after` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `dip` varchar(40) NOT NULL,
  `status` tinyint(4) NOT NULL default '0' COMMENT '0 - не законченный',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dips`
--

LOCK TABLES `dips` WRITE;
/*!40000 ALTER TABLE `dips` DISABLE KEYS */;
INSERT INTO `dips` (`id`, `user_id`, `title`, `description`, `tezis`, `sourse_before`, `sourse_after`, `name`, `time`, `ip`, `dip`, `status`) VALUES (10,0,'','','','d37c067c522f73d.jpg','d993f9e4a92cb90.jpg','',0,'92.55.27.25','',0),(11,0,'','','','def4e5307af517c.jpg','3e78248e218841c.jpg','',0,'92.55.27.25','',0),(12,0,'','','','bf230ca54363238.jpg','d5f8a835cda428d.jpg','',0,'92.55.27.25','',0),(13,0,'','','','8f8371aaa329915.jpg','3e8ba8ee05f318c.jpg','',0,'92.55.27.25','',0),(14,0,'','','','8f1974a8fb3f38f.jpg','3152247da76edaa.jpg','',0,'92.55.27.25','',0),(15,0,'','','','e437d6b4e69929b.jpg','f871763ad3d3a02.jpg','',0,'92.55.27.25','',0),(16,0,'','','','d08e6ce620096d6.jpg','f88a3afa4e5f62a.jpg','',0,'92.55.27.25','',0),(17,0,'','','','44d4f779466b26c.jpg','0d95095d8cf7bc5.jpg','',0,'92.55.27.25','',0),(18,0,'','','','47f40d843626b80.jpg','e0f884de71c09eb.jpg','',0,'92.55.27.25','',0),(19,0,'','','','f9bf5cdd76aa366.jpg','8cba6b48c87547c.jpg','',0,'92.55.27.25','',0),(20,0,'','','','2a506a5e4528f7a.jpg','14ac71202a6db3c.jpg','',0,'92.55.27.25','',0),(21,0,'','','','fd96f243cac474b.jpg','4413b931dd60b8a.jpg','',0,'92.55.27.25','',0),(22,0,'','','','b8bc20a44f9cc80.jpg','df171b0579e96c0.jpg','',0,'93.79.13.160','',0),(23,0,'','','','11846f51cf42fd0.jpg','89b46fcda7c5ae9.jpg','',0,'93.79.13.160','',0),(24,0,'','','','04614dae65841bd.jpg','41cd2fb6de3f2cc.jpg','',0,'93.79.13.160','',0),(25,0,'','','','b15d84f8d68f248.gif','ce9d71b925ea9ab.gif','',0,'93.79.13.160','',0),(26,0,'','','','e5ba28d8c2e695d.jpg','c699d39d34374d5.jpg','',0,'93.79.13.160','',0),(27,0,'','','','6f8fa1e85aa9d84.jpg','741147e013fa463.jpg','',0,'93.79.13.160','',0),(28,0,'','','','4c9a08d0a39d894.jpg','17ba98f06324dbb.jpg','',0,'93.79.13.160','',0),(29,0,'','','','13184643a97fb8e.jpg','b7aec9bad780c91.jpg','',0,'92.55.27.25','e56da225c3dba87.jpg',0),(30,0,'','','','d8dd295e6c7c7f5.jpg','7cf6cbcb40bea8f.jpg','',0,'178.63.68.167','474c34aa7f45366.jpg',0),(31,0,'','','','64aff874289769a.jpg','24186ef2af46e78.jpg','',0,'93.79.13.160','8d4be298a23fda0.jpg',0),(32,0,'','','','ab0647e120fd6a9.jpg','2836d60bb6d3035.jpg','',0,'93.79.13.160','77806d0d7852eb2.jpg',0),(33,0,'','','','bf7430826c800ad.jpg','8488bea7937b9f6.jpg','',0,'93.79.13.160','d6e69627760f234.jpg',0);
/*!40000 ALTER TABLE `dips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'monte122_monte122'
--
DELIMITER ;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-09-12 22:13:16
